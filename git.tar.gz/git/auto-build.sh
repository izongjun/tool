#!/bin/bash
# add build cmd here

echo '============ all success! ================='
exit 0
