#!/bin/bash 
echo "Running $BASH_SOURCE"
unset GIT_DIR
echo "PWD is $PWD"

branch="$1"

project_dir=$GIT_STORE_SHADE_DIR/$branch
build_dir=$project_dir/project/qnx

if [ ! -d "$project_dir" ]; then
	echo "project $project_dir is not exisit" 
fi

cd $project_dir 

git pull origin $branch:$branch
wait $!

	echo "=================================="
	echo "==   prepare to build $branch   =="
	echo "=================================="
	if [ -e "$GIT_AUTO_BUILD_CMD" ]; then
		bash $GIT_AUTO_BUILD_CMD
	elif [ -d "$build_dir" ];then
		cd $build_dir
		echo `pwd`
		chmod a+x make*
		./make-clean
		./make-release
    else
	    echo "build $build_dir is not exisit"
    fi
