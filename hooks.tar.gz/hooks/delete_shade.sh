#!/bin/bash
echo "Running $BASH_SOURCE"
unset GIT_DIR
echo "PWD is $PWD"

branch="$1"

if [ -z "$branch" -o -z "$GIT_STORE_SHADE_DIR" -o -z "$GIT_STORE_EXTEND_DIR" ];then
	echo "root dir or branch empty"
	exit 1
fi

cd $GIT_STORE_SHADE_DIR 
rm -rf $branch
