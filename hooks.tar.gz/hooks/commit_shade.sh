#!/bin/bash
echo "Running $BASH_SOURCE"
unset GIT_DIR
echo "PWD is $PWD"

branch="$1"

project_dir=$GIT_STORE_SHADE_DIR/$branch

if [ ! -d "$project_dir" ];then
	echo "project $project_dir is not exisit" 
fi

cd $project_dir
echo "$project_dir $branch"

git add .
git commit -m "update from auto build"

git push origin $branch:$branch
wait $!

exit 0
