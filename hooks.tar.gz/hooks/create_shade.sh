#!/bin/bash
echo "Running $BASH_SOURCE"
unset GIT_DIR
echo "PWD is $PWD"

branch="$1"

if [ -z "$branch" -o -z "$GIT_STORE_SHADE_DIR" -o -z "$GIT_STORE_EXTEND_DIR" ];then
	echo "root dir or branch empty"
	exit 1
fi

cd $GIT_STORE_SHADE_DIR 

#init from store
echo `pwd`

git clone -l -n $GIT_STORE_EXTEND_DIR $branch
cd $branch
git checkout $branch

git config user.name $GIT_AUTO_BUILD_UNAME
git config user.email $GIT_AUTO_BUILD_EMAIL

wait $!

exit 0
