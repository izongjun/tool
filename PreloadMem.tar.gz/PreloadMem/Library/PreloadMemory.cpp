#include "CMemoryManager.h"

void* operator new( size_t size )   
{ 
	//fprintf( stderr, "call new size: %d\n", size );
	return MemoryTrace::TraceMalloc( size );
}

void* operator new[](size_t size ) 
{ 
	//fprintf( stderr, "call new[] size: %d\n", size );
	return MemoryTrace::TraceMalloc( size );
}

void operator delete( void* ptr )  
{ 
	MemoryTrace::TraceFree( ptr );
}

void operator delete[]( void* ptr )    
{ 
	MemoryTrace::TraceFree( ptr );
}

extern "C"
{
	// void* malloc( size_t size )
	// {  
	//     return MemoryTrace::TraceMalloc( size );
	// }

	// void free( void* ptr )
	// {
	//     MemoryTrace::TraceFree( ptr );
	// }

	// void* calloc( size_t n, size_t len )
	// {
	//     return MemoryTrace::TraceCalloc( n, len );
	// }

	// void* realloc(void *ptr, size_t size)
	// {
	//     return MemoryTrace::TraceRealloc( ptr, size );
	// }

	// void* memalign(size_t blocksize, size_t bytes) 
	// {  
	//     return MemoryTrace::TraceMemalign( blocksize, bytes );
	// }

	// void* valloc(size_t size) 
	// {        
	//     return MemoryTrace::TraceValloc( size );
	// }

	// // int posix_memalign(void **memptr, size_t alignment, size_t size)
	// // {
	// //     return MemoryTrace::TracePosixMemalign( memptr, alignment, size );
	// // }

	// void *aligned_alloc(size_t alignment, size_t size)
	// {
	//     assert(false);
	// }

	// void *pvalloc(size_t size)
	// {
	//     assert(false);
	// }
}
