#ifndef __CMEMORYMANAGERH__
#define __CMEMORYMANAGERH__

#include <stddef.h>
#include <mutex>
#include <backtrace.h>

namespace MemoryTrace
{
	namespace Delegate
	{
		bool 					initialize();
		void					uninitilize();

		void					addRecord( const void* const ptr, size_t size );
		void					delRecord( const void* const ptr );
		bool					checkRecord( const void* const ptr );

		void 					storeBacktrace( char (*buffer)[128] );
		void 					showBacktrace( char (*buffer)[128] );
	}; //namespace delegate

	namespace MockMemory
	{
		bool 					initialize();
		void					uninitilize();

		void*               	_mockMalloc( size_t size );
		void*               	_mockCalloc( size_t nmemb, size_t size );
		void                	_mockFree( void* ptr );
	}; // namespace _mockMemory

	namespace ImpMemory
	{
		typedef void*           (*FUNC_MALLOC)( size_t );
		typedef void*           (*FUNC_CALLOC)( size_t, size_t );
		typedef void*           (*FUNC_REALLOC)( void *, size_t );
		typedef void*           (*FUNC_MEMALIGN)( size_t, size_t );
		typedef void*           (*FUNC_VALLOC)( size_t );
		typedef int             (*FUNC_POSIX_MEMALIGN)( void**, size_t, size_t );
		typedef void            (*FUNC_FREE)( void* );

		bool 					initialize();
		void					uninitilize();

		void*                   _impMalloc( size_t size, bool bRecursive = true );
		void*                   _impCalloc( size_t nmemb, size_t size, bool bRecursive = true );
		void*                   _impRealloc( void* ptr, size_t size, bool bRecursive = true );
		void*                   _impMemalign( size_t blocksize, size_t size, bool bRecursive = true );
		void*                   _impValloc( size_t size, bool bRecursive = true );
		int                     _impPosixMemalign( void** memptr, size_t alignment, size_t size, bool bRecursive = true );
		void                    _impFree( void* ptr, bool bRecursive = true );
	}; // namespace ImpMemory

    enum TraceStatus
    {   
        TS_UNINITIALIZE = 0,
        TS_INITIALIZING,
        TS_INITIALIZED,
        TS_FAILED,
    };

	void                    TraceInitialize();
	void                    TraceUninitialize();

	void*                   TraceMalloc( size_t size );
	void*                   TraceCalloc( size_t nmemb, size_t size );
	void*                   TraceRealloc( void* ptr, size_t size );
	void*                   TraceMemalign( size_t blocksize, size_t size );
	void*                   TraceValloc( size_t size );
	int                     TracePosixMemalign(void** memptr, size_t alignment, size_t size);
	void                    TraceFree( void* ptr );
}; // namespace MemoryTrace
#endif
