#include <dlfcn.h>
#include <cstdio>
#include <mutex>
#include <math.h>
#include <string.h>
#include <unistd.h>
#include <assert.h>
#include "CMemoryManager.h"

#include "Socket.h"

#ifndef OS_QNX
#include <execinfo.h>
#endif

#define BT_BUF_SIZE 20

namespace MemoryTrace
{
	namespace Delegate
	{
#define SOCKET_CLIENT_PATH    "/tmp/socket_client"
#define SOCKET_SERVER_PATH    "/tmp/socket_server"

		typedef Socket::CSocket::tagRecord    RECORD;

		static ::Socket::CSocket client;

		bool initialize()
		{
			assert( client.initSocket( false, SOCKET_CLIENT_PATH ) );
			assert( client.connect( SOCKET_SERVER_PATH ) );

			return true;
		}

		void uninitialize()
		{
			client.close();
		}

		void addRecord( const void* const ptr, size_t size )
		{
			if ( NULL == ptr ) return;

			RECORD* pRecord = (RECORD*)( client.buffer() );

			assert( NULL != pRecord );
			pRecord->sync	= DEF_SOCK_SYNC;
			pRecord->size 	= size;
			pRecord->data 	= ptr;

			storeBacktrace( pRecord->backtrace ); 
			client.send();
		}

		void delRecord( const void* const ptr )
		{
			if ( NULL == ptr ) return;

			RECORD* pRecord = (RECORD*)( client.buffer() );
			pRecord->sync	= DEF_SOCK_SYNC;
			pRecord->size 	= -1;
			pRecord->data 	= ptr;

			client.send();
		}

		bool checkRecord( const void* const ptr )
		{
			return NULL != ptr;
		}

		void storeBacktrace( char (*buffer)[128] )
		{
			if ( NULL == buffer ) return;

#ifdef OS_QNX
			//pNode->traceSize = bt_get_backtrace( &(s_unitManager.acc), pNode->backtrace, BT_BUF_SIZE );
#else
			void* 	bt[BT_BUF_SIZE];

			int 	size = backtrace( bt, BT_BUF_SIZE );
			char** 	str  = backtrace_symbols( bt, size );

			for ( int i=0; i < size; ++i ) {
				strncpy( buffer[i], str[i], 128 );
			}
#endif
		}

		void showBacktrace( char (*buffer)[128] )
		{
			if ( NULL == buffer ) return;
#ifdef OS_QNX
			//bt_sprnf_addrs( &s_unitManager.memmap, pNode->backtrace, pNode->traceSize, "%a\n", s_unitManager.out, sizeof(s_unitManager.out), 0 );
			//fprintf( stderr, "%s\n", s_unitManager.out );
#else
			//backtrace_symbols_fd( buffer, buffer, STDERR_FILENO );
#endif
		}
	} // namespace MemoryManager

	namespace MockMemory
	{
		static char             s_mockBuffer[1024 * 1024];
		static size_t           s_mockMallocPos = 0;

		bool initialize()
		{
			memset( s_mockBuffer, 0, 1024* 1024 );

			return true;
		}

		void uninitilize()
		{
			;
		}

		void* _mockMalloc( size_t size )
		{
			assert ( s_mockMallocPos + size < sizeof( s_mockBuffer ) );
			void* ptr = (void*)( s_mockBuffer + s_mockMallocPos );
			s_mockMallocPos += size;

			return ptr;
		}

		void* _mockCalloc( size_t nmemb, size_t size )
		{
			void* ptr = _mockMalloc( nmemb * size );
			for ( size_t i=0; i < nmemb * size; ++i )
				*( (char*)ptr + i ) = '\0';

			return ptr; 
		}

		void _mockFree( void* ptr )
		{
			;
		} 
	} //namespace MockMemory


	namespace ImpMemory
	{
		static FUNC_MALLOC          s_pRealMalloc           = NULL;
		static FUNC_CALLOC          s_pRealCalloc           = NULL;
		static FUNC_REALLOC         s_pRealRealloc          = NULL;
		static FUNC_MEMALIGN        s_pRealMemalign         = NULL;
		static FUNC_VALLOC          s_pRealValloc           = NULL;
		static FUNC_POSIX_MEMALIGN  s_pRealPosixMemalign    = NULL;
		static FUNC_FREE            s_pRealFree             = NULL;

		bool initialize()
		{
			s_pRealMalloc           = (FUNC_MALLOC)dlsym(RTLD_NEXT, "malloc");
			s_pRealCalloc           = (FUNC_CALLOC)dlsym(RTLD_NEXT, "calloc");
			s_pRealRealloc          = (FUNC_REALLOC)dlsym(RTLD_NEXT, "realloc");
			s_pRealMemalign         = (FUNC_MEMALIGN)dlsym(RTLD_NEXT, "memalign");
			s_pRealValloc           = (FUNC_VALLOC)dlsym(RTLD_NEXT, "valloc");
			s_pRealPosixMemalign    = (FUNC_POSIX_MEMALIGN)dlsym(RTLD_NEXT, "posix_memalign");
			s_pRealFree             = (FUNC_FREE)dlsym(RTLD_NEXT, "free");

			if ( NULL == s_pRealMalloc || NULL == s_pRealCalloc || NULL == s_pRealRealloc || 
					NULL == s_pRealMemalign || NULL == s_pRealValloc || NULL == s_pRealPosixMemalign || NULL == s_pRealFree )
				return false;

			return true;
		}

		void uninitilize()
		{
			;
		}

		void* _impMalloc( size_t size, bool bRecursive )
		{
			void* pData = s_pRealMalloc( size );
			if ( NULL == pData ) return NULL;

#ifdef _DEBUG
			if ( !bRecursive )
				fprintf( stderr, "===malloc: %p, size: %ld\n", pData, size );
#endif
			return pData;
		}

		void* _impCalloc( size_t nmemb, size_t size, bool bRecursive )
		{
			void* pData = s_pRealCalloc( nmemb, size );
			if ( NULL == pData ) return NULL;

#ifdef _DEBUG
			if ( !bRecursive )
				fprintf( stderr, "===calloc: %p, size: %ld\n", pData, size );
#endif
			return pData;
		}

		void* _impRealloc( void* ptr, size_t size, bool bRecursive )
		{
			void* pData = s_pRealCalloc( ptr, size );
			if ( NULL == pData ) return NULL;

#ifdef _DEBUG
			if ( !bRecursive )
				fprintf( stderr, "===realloc: %p, size: %ld\n", pData, size );
#endif
			return pData;
		}

		void* _impMemalign( size_t blocksize, size_t size, bool bRecursive )
		{
			void* pData = s_pRealMemalign( blocksize, size );
			if ( NULL == pData ) return NULL;

#ifdef _DEBUG
			if ( !bRecursive )
				fprintf( stderr, "===memalign: %p, size: %ld\n", pData, size );
#endif
			return pData;
		}

		void* _impValloc( size_t size, bool bRecursive )
		{
			void* pData = s_pRealValloc( size );
			if ( NULL == pData ) return NULL;

#ifdef _DEBUG
			if ( !bRecursive )
				fprintf( stderr, "===valloc: %p, size: %ld\n", pData, size );
#endif
			return pData;
		}

		int _impPosixMemalign(void** memptr, size_t alignment, size_t size, bool bRecursive )
		{ 
			int ret = s_pRealPosixMemalign( memptr, alignment, size );
			if ( 0 != ret ) return ret;

#ifdef _DEBUG
			if ( !bRecursive )
				fprintf( stderr, "===posix_memalign: %p, size: %ld\n", *memptr, size );
#endif
			return ret;
		}

		void _impFree( void* ptr, bool bRecursive )
		{
			if ( NULL == ptr ) return;

#ifdef _DEBUG
			if ( !bRecursive )
				fprintf( stderr, "===free %p\n", ptr );
#endif        
			s_pRealFree( ptr );
		}
	}; // namespace ImpMemory

	static TraceStatus s_status = TS_UNINITIALIZE;
	static pthread_mutex_t  s_mutexInit = PTHREAD_MUTEX_INITIALIZER;
	void TraceInitialize()
	{
		pthread_mutex_lock( &s_mutexInit );
		if ( s_status == TS_INITIALIZED ) { pthread_mutex_unlock( &s_mutexInit ); return; }

		s_status = TS_INITIALIZING;

		MockMemory::initialize();
		ImpMemory::initialize();
		Delegate::initialize();

		s_status = TS_INITIALIZED;

		pthread_mutex_unlock( &s_mutexInit );
	}

	void TraceUninitialize()
	{
		//MemoryManager::analyse(false);
		MockMemory::uninitilize();
		ImpMemory::uninitilize();
		Delegate::uninitilize();
	}

	static int s_no_hook = 0;
	void* TraceMalloc( size_t size )
	{  
		if ( 0 == size ) return NULL;
		if ( s_status == TS_INITIALIZING ) return MockMemory::_mockMalloc( size );      
		if ( s_status != TS_INITIALIZED )  TraceInitialize();

		void* p = ImpMemory::_impMalloc( size, __sync_fetch_and_add( &s_no_hook, 1 ) );
		Delegate::addRecord( p, size );
		__sync_fetch_and_sub( &s_no_hook, 1 );
		return p;
	}

	void* TraceCalloc( size_t nmemb, size_t size )
	{ 
		if ( 0 == nmemb || 0 == size ) return NULL;       
		if ( s_status == TS_INITIALIZING ) return MockMemory::_mockCalloc( nmemb, size );
		if ( s_status != TS_INITIALIZED )  TraceInitialize();

		void* p = ImpMemory::_impCalloc( nmemb, size, __sync_fetch_and_add( &s_no_hook, 1 ) );
		Delegate::addRecord( p, nmemb * size );
		__sync_fetch_and_sub( &s_no_hook, 1 );
		return p;
	}

	void* TraceRealloc( void *ptr, size_t size )
	{
		if ( s_status != TS_INITIALIZED )  TraceInitialize();

		void* p = ImpMemory::_impRealloc( ptr, size, __sync_fetch_and_add( &s_no_hook, 1 ) );
		Delegate::addRecord( p, size );
		__sync_fetch_and_sub( &s_no_hook, 1 );
		return p;
	}

	void* TraceMemalign( size_t blocksize, size_t size )
	{
		if ( 0 == size ) return NULL;
		if ( s_status != TS_INITIALIZED )  TraceInitialize();

		void* p = ImpMemory::_impMemalign( blocksize, size, __sync_fetch_and_add( &s_no_hook, 1 ) );
		Delegate::addRecord( p, size );
		__sync_fetch_and_sub( &s_no_hook, 1 );
		return p;
	}

	void* TraceValloc( size_t size )
	{
		if ( 0 == size ) return NULL;
		if ( s_status != TS_INITIALIZED )  TraceInitialize();

		void* p = ImpMemory::_impValloc( size, __sync_fetch_and_add( &s_no_hook, 1 ) );
		Delegate::addRecord( p, size );
		__sync_fetch_and_sub( &s_no_hook, 1 );
		return p;
	}

	int TracePosixMemalign(void** memptr, size_t alignment, size_t size)
	{
		if ( 0 == size ) { (*memptr) = NULL; return ENOMEM; }
		if ( s_status != TS_INITIALIZED )  TraceInitialize();

		int ret = ImpMemory::_impPosixMemalign( memptr, alignment, size, __sync_fetch_and_add( &s_no_hook, 1 ) );
		Delegate::addRecord( *memptr, size );
		__sync_fetch_and_sub( &s_no_hook, 1 );
		return ret;
	}

	void TraceFree( void* ptr )
	{
		if ( s_status == TS_INITIALIZING ) return MockMemory::_mockFree( ptr );        
		if ( s_status != TS_INITIALIZED )  TraceInitialize();

		Delegate::delRecord( ptr );
		ImpMemory::_impFree( ptr, __sync_fetch_and_add( &s_no_hook, 1 ) );
		__sync_fetch_and_sub( &s_no_hook, 1 );
	}
}
