#include <dlfcn.h>
#include <cstdio>
#include <mutex>
#include <math.h>
#include <string.h>
#include <unistd.h>
#include "CMemoryManager.h"

#include "Socket.h"

#ifndef OS_QNX
#include <execinfo.h>
#endif

#define SOCKET_CLIENT_PATH    "./socket_client"
#define SOCKET_SERVER_PATH    "./socket_server"

namespace MemoryTrace
{
    namespace MemoryManager
    {
		static CSocket client;
        void initialize()
        {
			assert( client.initSocket( false, SOCKET_CLIENT_PATH ) );
			assert( client.connect( SOCKET_SERVER_PATH ) );
        }

        void uninitialize()
        {
			client.close();
        }

        void makeUnit(tagUnitNode* const pNode, size_t size)
        {
            if ( NULL == pNode ) return;

			tagRecord* pRecord = static_cast<tagRecord*>( client.buffer() );
			pRecord->sync	= DEF_SOCK_SYNC;
			pRecord->size 	= size;
			pRecord->data 	= PTR_UNIT_NODE_DATA( pNode );
            
            storeBacktrace( pRecord->backtrace ); 
        }

        static pthread_mutex_t s_mutexMemory = PTHREAD_MUTEX_INITIALIZER;      
        void appendUnit( tagUnitNode* pNode )
        {
			/*
            if ( NULL == pNode ) return;

            pthread_mutex_lock( &s_mutexMemory );
            assert( pNode != s_unitManager.pCurrent );
            pNode->pPrev    = s_unitManager.pCurrent;
            pNode->pNext    = NULL;

            assert( NULL != s_unitManager.pCurrent );
            s_unitManager.pCurrent->pNext   = pNode;
            s_unitManager.pCurrent          = pNode;

            s_unitManager.totalSize += pNode->size;
            s_unitManager.availSize += pNode->size - DEF_SIZE_UNIT_NODE;
            s_unitManager.unitCount += 1;

            pthread_mutex_unlock( &s_mutexMemory );  
			*/
            if ( NULL == pNode ) return;

            pthread_mutex_lock( &s_mutexMemory );
			client.send();
            pthread_mutex_unlock( &s_mutexMemory );  
        }

        void deleteUnit( tagUnitNode* pNode )
        {     
			/*
            if ( NULL == pNode ) return;

            pthread_mutex_lock( &s_mutexMemory );
            assert( NULL != pNode->pPrev );
            pNode->pPrev->pNext = pNode->pNext;

            if ( NULL != pNode->pNext )
                pNode->pNext->pPrev = pNode->pPrev;

            if ( s_unitManager.pCurrent == pNode )
                s_unitManager.pCurrent = pNode->pPrev;

            pNode->pPrev = NULL;
            pNode->pNext = NULL;

            s_unitManager.totalSize -= pNode->size;
            s_unitManager.availSize -= pNode->size - DEF_SIZE_UNIT_NODE;
            s_unitManager.unitCount -= 1;

            pthread_mutex_unlock( &s_mutexMemory );
			*/
            if ( NULL == pNode ) return;

            pthread_mutex_lock( &s_mutexMemory );
			tagRecord* pRecord 	= static_cast<tagRecord*>( client.buffer() );
			pRecord->sync		= DEF_SOCK_SYNC;
			pRecord->size 		= -1;
			pRecord->data 		= PTR_UNIT_NODE_DATA( pNode );
			client.send();
            pthread_mutex_unlock( &s_mutexMemory );
        }

        bool checkUnit( tagUnitNode* pNode )
        {
            if ( NULL == pNode || MAKE_UNIT_NODE_MAGIC(pNode->pData) != pNode->sign ) return false;

            return true;
        }

        void analyse( bool autoDelete )
        {
			/*
            fprintf( stderr, "++++++++++++++ check ++++++++++++++\n" );
            fprintf( stderr, "\tunfreed:\t%ld\n\tsize:\t\t%ld\n", s_unitManager.unitCount, s_unitManager.availSize );
                
            tagUnitNode* pNode = s_unitManager.headUnit.pNext;
            tagUnitNode* pCur  = NULL;

            while ( NULL != pNode ) 
            {
                pCur    = pNode;
                pNode   = pNode->pNext;
                if ( pCur == pNode ) break;

                fprintf( stderr, "++++++++++++++ unfree addr: %p, size: %ld ++++++++++++++\n", \
                             pCur, \
                             pCur->size - DEF_SIZE_UNIT_NODE );
                fprintf( stderr, "backtrace:\n" );
                showBacktrace( pCur );              
                fprintf( stderr, "++++++++++++++ end ++++++++++++++\n" );
                
                if ( autoDelete ) TraceFree( pCur );
            }
			*/
        }

        void storeBacktrace( char* const buffer )
        {
            if ( NULL == pNode ) return;

#ifdef OS_QNX
            //pNode->traceSize = bt_get_backtrace( &(s_unitManager.acc), pNode->backtrace, BT_BUF_SIZE );
#else
			void* 	bt[BT_BUF_SIZE];

            int 	size = backtrace( bt, BT_BUF_SIZE );
			char** 	str  = backtrace_symbols( bt, size );

			strncpy( buff, *str, 1000 );
#endif
        }
   
        void showBacktrace( char* const buffer )
        {
            if ( NULL == pNode ) return;
#ifdef OS_QNX
            //bt_sprnf_addrs( &s_unitManager.memmap, pNode->backtrace, pNode->traceSize, "%a\n", s_unitManager.out, sizeof(s_unitManager.out), 0 );
            //fprintf( stderr, "%s\n", s_unitManager.out );
#else
            backtrace_symbols_fd( buffer, pNode->traceSize, STDERR_FILENO );
#endif
        }
    } // namespace MemoryManager

    namespace mockMemory
    {
        static char             s_mockBuffer[1024 * 1024];
        static size_t           s_mockMallocPos = 0;

        void* _mockMalloc( size_t size )
        {
            assert ( s_mockMallocPos + size < sizeof( s_mockBuffer ) );
            void* ptr = (void*)( s_mockBuffer + s_mockMallocPos );
            s_mockMallocPos += size;

            return ptr;
        }

        void* _mockCalloc( size_t nmemb, size_t size )
        {
            void* ptr = _mockMalloc( nmemb * size );
            for ( size_t i=0; i < nmemb * size; ++i )
                *( (char*)ptr + i ) = '\0';

            return ptr; 
        }

        void _mockFree( void* ptr )
        {
            ;
        } 
    } //namespace mockMemory

    enum TraceStatus
    {   
        TS_UNINITIALIZE = 0,
        TS_INITIALIZING,
        TS_INITIALIZED,
        TS_FAILED,
    };
   
    static TraceStatus          s_status                = TS_UNINITIALIZE;
    static FUNC_MALLOC          s_pRealMalloc           = NULL;
    static FUNC_CALLOC          s_pRealCalloc           = NULL;
    static FUNC_REALLOC         s_pRealRealloc          = NULL;
    static FUNC_MEMALIGN        s_pRealMemalign         = NULL;
    static FUNC_VALLOC          s_pRealValloc           = NULL;
    static FUNC_POSIX_MEMALIGN  s_pRealPosixMemalign    = NULL;
    static FUNC_FREE            s_pRealFree             = NULL;

    static pthread_mutex_t  s_mutexInit = PTHREAD_MUTEX_INITIALIZER;
    void TraceInitialize()
    {
        pthread_mutex_lock( &s_mutexInit );
        if ( s_status == TS_INITIALIZED ) { pthread_mutex_unlock( &s_mutexInit ); return; }

        s_status = TS_INITIALIZING;
       
        s_pRealMalloc           = (FUNC_MALLOC)dlsym(RTLD_NEXT, "malloc");
        s_pRealCalloc           = (FUNC_CALLOC)dlsym(RTLD_NEXT, "calloc");
        s_pRealRealloc          = (FUNC_REALLOC)dlsym(RTLD_NEXT, "realloc");
        s_pRealMemalign         = (FUNC_MEMALIGN)dlsym(RTLD_NEXT, "memalign");
        s_pRealValloc           = (FUNC_VALLOC)dlsym(RTLD_NEXT, "valloc");
        s_pRealPosixMemalign    = (FUNC_POSIX_MEMALIGN)dlsym(RTLD_NEXT, "posix_memalign");
        s_pRealFree             = (FUNC_FREE)dlsym(RTLD_NEXT, "free");

        assert( !( NULL == s_pRealMalloc || NULL == s_pRealCalloc || NULL == s_pRealRealloc || 
                    NULL == s_pRealMemalign || NULL == s_pRealValloc || NULL == s_pRealPosixMemalign || NULL == s_pRealFree ) );

        MemoryManager::initialize();
        s_status = TS_INITIALIZED;

        pthread_mutex_unlock( &s_mutexInit );
    }

    void TraceUninitialize()
    {
        MemoryManager::analyse(false);
    }

    static int s_no_hook = 0;
    void* TraceMalloc( size_t size )
    {  
        if ( 0 == size ) return NULL;
        if ( s_status == TS_INITIALIZING ) return mockMemory::_mockMalloc( size );      
        if ( s_status != TS_INITIALIZED )  TraceInitialize();

        void* p = _impMalloc( size, __sync_fetch_and_add( &s_no_hook, 1 ) );
        __sync_fetch_and_sub( &s_no_hook, 1 );
        return p;
    }

    void* TraceCalloc( size_t nmemb, size_t size )
    { 
        if ( 0 == nmemb || 0 == size ) return NULL;       
        if ( s_status == TS_INITIALIZING ) return mockMemory::_mockCalloc( nmemb, size );
        if ( s_status != TS_INITIALIZED )  TraceInitialize();

        void* p = _impCalloc( nmemb, size, __sync_fetch_and_add( &s_no_hook, 1 ) );
        __sync_fetch_and_sub( &s_no_hook, 1 );
        return p;
    }

    void* TraceRealloc( void *ptr, size_t size )
    {
        if ( s_status != TS_INITIALIZED )  TraceInitialize();

        void* p = _impRealloc( ptr, size, __sync_fetch_and_add( &s_no_hook, 1 ) );
        __sync_fetch_and_sub( &s_no_hook, 1 );
        return p;
    }

    void* TraceMemalign( size_t blocksize, size_t size )
    {
        if ( 0 == size ) return NULL;
        if ( s_status != TS_INITIALIZED )  TraceInitialize();

        void* p = _impMemalign( blocksize, size, __sync_fetch_and_add( &s_no_hook, 1 ) );
        __sync_fetch_and_sub( &s_no_hook, 1 );
        return p;
    }
    
    void* TraceValloc( size_t size )
    {
        if ( 0 == size ) return NULL;
        if ( s_status != TS_INITIALIZED )  TraceInitialize();

        void* p = _impValloc( size, __sync_fetch_and_add( &s_no_hook, 1 ) );
        __sync_fetch_and_sub( &s_no_hook, 1 );
        return p;
    }

    int TracePosixMemalign(void** memptr, size_t alignment, size_t size)
    {
        if ( 0 == size ) { (*memptr) = NULL; return ENOMEM; }
        if ( s_status != TS_INITIALIZED )  TraceInitialize();

        int ret = _impPosixMemalign( memptr, alignment, size, __sync_fetch_and_add( &s_no_hook, 1 ) );
        __sync_fetch_and_sub( &s_no_hook, 1 );
        return ret;
    }
    
    void TraceFree( void* ptr )
    {
        if ( s_status == TS_INITIALIZING ) return mockMemory::_mockFree( ptr );        
        if ( s_status != TS_INITIALIZED )  TraceInitialize();

        _impFree( ptr, __sync_fetch_and_add( &s_no_hook, 1 ) );
        __sync_fetch_and_sub( &s_no_hook, 1 );
    }

    void* _impMalloc( size_t size, bool bRecursive )
    {
        MemoryManager::tagUnitNode* pNode = (MemoryManager::tagUnitNode*)s_pRealMalloc( size + DEF_SIZE_UNIT_NODE );
        if ( NULL == pNode ) return NULL;

        MemoryManager::makeUnit( pNode, size + DEF_SIZE_UNIT_NODE );
        MemoryManager::appendUnit( pNode );

#ifdef _DEBUG
        if ( !bRecursive )
            fprintf( stderr, "===malloc: %p, size: %ld, real: %ld\n", pNode, pNode->size, pNode->size - DEF_SIZE_UNIT_NODE );
#endif
        return PTR_UNIT_NODE_DATA( pNode );
    }

    void* _impCalloc( size_t nmemb, size_t size, bool bRecursive )
    {
        nmemb = ceil( (double)( size * nmemb + DEF_SIZE_UNIT_NODE ) / (double)size );
        MemoryManager::tagUnitNode* pNode = (MemoryManager::tagUnitNode*)s_pRealCalloc( nmemb, size );
        if ( NULL == pNode ) return NULL;
        
        MemoryManager::makeUnit( pNode, nmemb * size );
        MemoryManager::appendUnit( pNode );

#ifdef _DEBUG
        if ( !bRecursive )
            fprintf(stderr, "===calloc: %p, size: %ld, real: %ld\n", pNode, pNode->size, pNode->size - DEF_SIZE_UNIT_NODE);
#endif
        return PTR_UNIT_NODE_DATA( pNode );
    }

    void* _impRealloc( void* ptr, size_t size, bool bRecursive )
    {
        void* ret = NULL;
        if ( NULL == ptr ) {
            if ( 0 == size ) {
                ; // do nothing
            } else {
                // malloc
                ret = _impMalloc( size, true );
            }
        } else {
            if ( 0 == size ) {
                // free
                _impFree( ptr, true );
            } else {
                // get old size
                MemoryManager::tagUnitNode* pNodeLast = PTR_UNIT_NODE_HEADER( ptr );
                assert( MemoryManager::checkUnit( pNodeLast ) );
                size_t lastSize = pNodeLast->size - DEF_SIZE_UNIT_NODE;

                if ( lastSize >= size ) {
                    // just return old ptr
                    ret = ptr;
                } else {
                    ret = _impMalloc( size, true );
                    if ( NULL == ret ) ret = ptr;   // if malloc failed, return old pointer

                    memcpy( ret, ptr, lastSize );
                    _impFree( ptr, true );
                }
            }
        }

        return ret;
    }

    void* _impMemalign( size_t blocksize, size_t size, bool bRecursive )
    {
        MemoryManager::tagUnitNode* pNode = (MemoryManager::tagUnitNode*)s_pRealMemalign( blocksize, size + DEF_SIZE_UNIT_NODE );
        if ( NULL == pNode ) return NULL;
        
        MemoryManager::makeUnit( pNode, size + DEF_SIZE_UNIT_NODE );
        MemoryManager::appendUnit( pNode );

#ifdef _DEBUG
        if ( !bRecursive )
            fprintf(stderr, "===memalign: %p, size: %ld, real: %ld\n", pNode, pNode->size, pNode->size - DEF_SIZE_UNIT_NODE);
#endif
        return PTR_UNIT_NODE_DATA( pNode );
    }

    void* _impValloc( size_t size, bool bRecursive )
    {
        MemoryManager::tagUnitNode* pNode = (MemoryManager::tagUnitNode*)s_pRealValloc( size + DEF_SIZE_UNIT_NODE );
        if ( NULL == pNode ) return NULL;
        
        MemoryManager::makeUnit( pNode, size + DEF_SIZE_UNIT_NODE );
        MemoryManager::appendUnit( pNode );

#ifdef _DEBUG
        if ( !bRecursive )
            fprintf(stderr, "===valloc: %p, size: %ld, real: %ld\n", pNode, pNode->size, pNode->size - DEF_SIZE_UNIT_NODE);
#endif
        return PTR_UNIT_NODE_DATA( pNode );
    }

    int _impPosixMemalign(void** memptr, size_t alignment, size_t size, bool bRecursive )
    { 
        int ret = s_pRealPosixMemalign( memptr, alignment, size + DEF_SIZE_UNIT_NODE );
        MemoryManager::tagUnitNode* pNode = (MemoryManager::tagUnitNode*)( *memptr );
        if ( 0 != ret ) return ret;
        
        MemoryManager::makeUnit( pNode, size + DEF_SIZE_UNIT_NODE );
        MemoryManager::appendUnit( pNode );

#ifdef _DEBUG
        if ( !bRecursive )
            fprintf(stderr, "===posix_memalign: %p, size: %ld, real: %ld\n", pNode, pNode->size, pNode->size - DEF_SIZE_UNIT_NODE);
#endif
        return ret;
    }
    
    void _impFree( void* ptr, bool bRecursive )
    {
        if ( NULL == ptr ) return;
        MemoryManager::tagUnitNode* pNode = PTR_UNIT_NODE_HEADER( ptr );
        if ( !MemoryManager::checkUnit( pNode ) )
        {
            fprintf(stderr, "unknow freed deleteUnit: %lx, %lx, %p\n", MAKE_UNIT_NODE_MAGIC( pNode->pData ), pNode->sign, pNode);
            s_pRealFree( ptr );

            return;
        }
        assert ( pNode->size > DEF_SIZE_UNIT_NODE );

#ifdef _DEBUG
        if ( !bRecursive )
            fprintf(stderr, "===free %p, node: %p, size: %ld, real: %ld\n", ptr, pNode, pNode->size, pNode->size - DEF_SIZE_UNIT_NODE);
#endif        
        MemoryManager::deleteUnit( pNode );
        s_pRealFree( pNode );
    }
}
