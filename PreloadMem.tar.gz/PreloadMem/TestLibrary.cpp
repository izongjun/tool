#include <stdlib.h>
#include <stdio.h>

class AA
{
public:
	AA()
	:a(NULL)
	{
		a = new int[20];
	}
	~AA()
	{
		if ( a!= NULL ) delete [] a;
	}

private:
	int* a;
};

extern "C"
{
    void foo( int i )
    {
        fprintf( stderr, " call foo: %d\n ", i );
        AA* aA = new AA();
        AA  aB;
        AA*  aC = (AA*)malloc(sizeof(AA));

        int iA[10];
        int* iB = new int[20];
        int* iC = (int*)malloc(sizeof(int) * 30);

        char cA[10];
        char* cB = new char[20];
        char* cC = (char*)malloc( sizeof(char) * 30 );

        delete aA;
        delete aC;

        delete [] iB;
        delete [] iC;

        delete [] cB;
        delete [] cC;
    }
}