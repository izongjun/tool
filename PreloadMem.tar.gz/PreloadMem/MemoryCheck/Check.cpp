#include <stdio.h>

#define LISTEN_BACKLOG      50
#define SOCK_BIND_PATH    "./socket_server"

static bool bExit = false;

void run()
{
	socket::CSocket server;
	socket::CSocket client;
	assert( server.initServer( true, SOCK_BIND_PATH) );

    timeval tv;
    tv.tv_sec = 3;      // 3s timeout
    tv.tv_nsec = 0;
	
	socklen_t addrLen;

    while ( !bExit ) {
        fd_set  rset;
        int     maxfd = -1;
		
		// init rset
        FD_ZERO( &rset );
        if ( server.available() ) {
            if ( maxfd < server.fd() ) maxfd = server.fd();
            FD_SET( server.fd(), &rset );
        }
        if ( client.available() ) {
            if ( maxfd < client.fd() ) maxfd = client.fd();
            FD_SET( client.fd(), &rset );
        }

		// select
        int ret = select( maxfd + 1, &rset, NULL, NULL, &tv );
        if ( bExit ) return;
        assert ( -1 != ret );

        if ( FD_ISSET( server.fd(), &rset ) ) {
         	// receive new client
			if ( client.available() ) client.close();

            client.fd( accept( server.fd(), &client.addr, &addrLen );
            assert( client.available() );
        } else if ( FD_ISSET( client.fd(), &rset ) ) {
            // receive new data
           	assert( DEF_SIZE_OF_RECORD == client.recv() );
			
			tagRecord* pRecord = static_cast<tagRecord*>( client.buffer );
			assert( DEF_SOCK_SYNC == pRecord->sync );
			
			if ( pRecord->size == -1 ) {
				// delete
				MemoryManager::deleteUnit( pRecord->pData );
			} else {
				MemoryManager::appendUnit( pRecord->size, pRecord->pData, pRecord->backtrace );
			}
        } else {
			// invalid
            ;
        }
    }
}

int main(int argc, char** argv)
{
    if ( argc < 2 ) {
        fprintf(stderr, "usage: memcheck [program]!!\n");
        return 0;
    }

    int pid = fork();
    if ( -1 == pid ) {
        fprintf( stderr, "error in fork\n" );
    }
    
    if ( 0 == pid ) {
        // child
        // call exec to run argv[1]
        const char* binary = argv[1];
        char*       envp[] = { "LD_PRELOAD=./libPreload.so", "LD_LIBRARY_PATH=.", (char*)NULL };

        execle( binary, "", (char*)NULL, envp );
    } else {
        // parent
		std::thread monitor( run );

        waitpid(pid);
		bExit = true;

		monitor.join();
    }

    return 0;
}
