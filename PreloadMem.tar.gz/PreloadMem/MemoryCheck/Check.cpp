#include <stdio.h>
#include <assert.h>
#include <sys/select.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <signal.h>

#include <thread>

#include "Socket.h"
#include "CMemoryCheck.h"

#define LISTEN_BACKLOG          50
#define SOCKET_SERVER_PATH      "/tmp/socket_server"

typedef Socket::CSocket::tagRecord    RECORD;

static bool bExit = false;

void run()
{
	Socket::CSocket server;
	Socket::CSocket client;
	assert( server.initSocket( true, SOCKET_SERVER_PATH ) );

    timeval tv;
    tv.tv_sec   = 3;      // 3s timeout
    tv.tv_usec  = 0;
	
	socklen_t addrLen;

    while ( !bExit ) {
        fd_set  rset;
        int     maxfd = -1;
		
		// init rset
        FD_ZERO( &rset );
        if ( server.available() ) {
            if ( maxfd < server.fd() ) maxfd = server.fd();
            FD_SET( server.fd(), &rset );
        }
        if ( client.available() ) {
            if ( maxfd < client.fd() ) maxfd = client.fd();
            FD_SET( client.fd(), &rset );
        }

		// select
        int ret = select( maxfd + 1, &rset, NULL, NULL, &tv );
        if ( bExit ) return;
        assert ( -1 != ret );

        if ( FD_ISSET( server.fd(), &rset ) ) {
         	// receive new client
			if ( client.available() ) client.close();

            client.fd( accept( server.fd(), ( sockaddr* )&( client.addr() ), &addrLen ) );
            assert( client.available() );

            assert( -1 != getpeername( client.fd(), ( sockaddr* )&( client.addr() ), &addrLen ) );
            fprintf( stderr, "get Client socket filepath: %s\n", client.addr().sun_path );

        } else if ( FD_ISSET( client.fd(), &rset ) ) {
            // receive new data
           	if ( -1 == client.recv() ) { perror(" recv "); exit(-1); }
			
			RECORD* pRecord = (RECORD*)( client.buffer() );
			if ( pRecord->data == NULL ) continue;
            
            //assert( DEF_SOCK_SYNC == pRecord->sync );
			
			if ( pRecord->size == -1 ) {
				// delete
				MemoryManager::deleteUnit( pRecord->data );
			} else {
				MemoryManager::appendUnit( pRecord->size, pRecord->data, pRecord->backtrace );
			}
        } else {
			// invalid
            ;
        }
    }
}

void handle_sigint( int sig ) 
{ 
    fprintf(stderr, "Caught signal %d\n", sig); 
    if ( sig == SIGINT )
        bExit = true;
} 

int main(int argc, char** argv)
{
    if ( argc < 2 ) {
        fprintf(stderr, "usage: memcheck [program]!!\n");
        return 0;
    }

    int pid = fork();
    if ( -1 == pid ) {
        fprintf( stderr, "error in fork\n" );
    }
    
    if ( 0 == pid ) {
        // child
        // call exec to run argv[1]
        const char* binary = argv[1];
        char*       envp[] = { "LD_LIBRARY_PATH=.", (char*)NULL };
        
        //execl( binary, "", (char*)NULL, envp );  
    } else {
        // parent
        signal(SIGINT, handle_sigint);
		std::thread monitor( run );

        //int status = -1;
        //waitpid( pid, &status, 0 );
		//bExit = true;

		monitor.join();
        MemoryManager::analyse();
    }

    return 0;
}
