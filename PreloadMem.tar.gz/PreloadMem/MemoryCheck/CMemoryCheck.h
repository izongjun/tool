#ifndef __CMEMORY_CHECKH__
#define __CMEMORY_CHECKH__

#include <stddef.h>

#define BT_BUF_SIZE 20
namespace MemoryManager
{
    struct tagUnitNode
    {
        size_t          size;
        void*           pData;
        char			backtrace[BT_BUF_SIZE][128];
    };
    
    void                initialize();
    void                uninitialize();
    void                appendUnit( size_t size, void* pData, char (*bt)[128] );
    void                deleteUnit( void* pData );
	void 				analyse();
}; // namespace MemoryManager

#endif
