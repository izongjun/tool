#ifndef __CMEMORY_CHECKH__
#define __CMEMORY_CHECKH__

#define BT_BUF_SIZE 1024
namespace MemoryManager
{
    struct tagUnitNode
    {
        size_t          size;
        void*           pData;
        char            backtrace[ BT_BUF_SIZE ];
    };
    
    void                initialize();
    void                uninitialize();
    void                appendUnit( size_t size, void* pData, const char* bt );
    void                deleteUnit( void* pData );
	void 				analyse();
}; // namespace MemoryManager

#endif
