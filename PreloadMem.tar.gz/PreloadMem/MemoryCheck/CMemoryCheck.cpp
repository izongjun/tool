#include "CMemoryCheck.h"

namespace MemoryManager
{
    #define DEF_SIZE_UNIT_NODE                          sizeof( MemoryManager::tagUnitNode )
    
    #define PTR_UNIT_NODE_HEADER(ptr_unit_data)			( MemoryManager::tagUnitNode* )( (char*)ptr_unit_data - DEF_SIZE_UNIT_NODE )
    #define PTR_UNIT_NODE_DATA(ptr_unit_hdr)			( void* )( (char*)ptr_unit_hdr + DEF_SIZE_UNIT_NODE )
    
    static size_t   total_size = 0;
    static size_t   avail_size = 0;
    static std::map< size_t, tagUnitNode >  s_mapManager;

    void initialize()
    {
        ;
    }

    void uninitialize()
    {
        ;
    }

    static std::mutex g_mutexManager;
    void appendUnit( size_t size, void* pData, const char* bt )
    {
        if ( 0 == size || !pData ) return ;

        // make new unit
        tagUnitNode* pNode  = new tagUnitNode();
        pNode->size     = size;
        strncpy( pNode->backtrace, bt, BT_BUF_SIZE );

        std::lock_guard<std::mutex> lock( g_mutexManager );
        s_mapManager[static_cast<size_t>(pData)] = pNode;
    }

    void deleteUnit( void* pData )
    {        
        if ( !pData ) return;

        s_mapManager.erase( (size_t)pData );
    }

    void analyse( )
    {
        fprintf( stderr, "++++++++++++++ check ++++++++++++++\n" );
        fprintf( stderr, "\tunfreed:\t%ld\n\tsize:\t\t%ld\n", s_unitManager.unitCount, s_unitManager.availSize );
            
        tagUnitNode* pNode = s_unitManager.headUnit.pNext;
        tagUnitNode* pCur  = NULL;

        while ( NULL != pNode )
        {
            pCur    = pNode;
            pNode   = pNode->pNext;
            if ( pCur == pNode ) break;

            fprintf( stderr, "++++++++++++++ unfree addr: %p, size: %ld ++++++++++++++\n", \
                            pCur, \
                            pCur->size - DEF_SIZE_UNIT_NODE );
            fprintf( stderr, "backtrace:\n" );
            showBacktrace( pCur );              
            fprintf( stderr, "++++++++++++++ end ++++++++++++++\n" );
            
            if ( autoDelete ) TraceFree( pCur );
        }
    }
} // namespace MemoryManager
