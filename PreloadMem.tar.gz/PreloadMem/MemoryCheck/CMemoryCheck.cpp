#include "CMemoryCheck.h"
#include <map>
#include <mutex>
#include <string.h>

namespace MemoryManager
{
    #define DEF_SIZE_UNIT_NODE                          sizeof( MemoryManager::tagUnitNode )
    
    #define PTR_UNIT_NODE_HEADER(ptr_unit_data)			( MemoryManager::tagUnitNode* )( (char*)ptr_unit_data - DEF_SIZE_UNIT_NODE )
    #define PTR_UNIT_NODE_DATA(ptr_unit_hdr)			( void* )( (char*)ptr_unit_hdr + DEF_SIZE_UNIT_NODE )
    
    static size_t   alloc_size = 0;
    static std::map< size_t, tagUnitNode* >  s_mapManager;

    void initialize()
    {
        ;
    }

    void uninitialize()
    {
        ;
    }

    static std::mutex g_mutexManager;
    void appendUnit( size_t size, void* pData, char (*bt)[128] )
    {
        if ( 0 == size || !pData ) return ;

        // make new unit
        tagUnitNode* pNode  = new tagUnitNode();
        pNode->size     = size;

        for ( int i = 0; i < BT_BUF_SIZE; ++i )
            strncpy( pNode->backtrace[i], bt[i], 128 );

        std::lock_guard<std::mutex> lock( g_mutexManager );
        s_mapManager[(size_t)(pData)] = pNode;
    }

    void deleteUnit( void* pData )
    {        
        if ( !pData ) return;
        
        s_mapManager.erase( (size_t)pData );
    }

    void analyse( )
    {
        fprintf( stderr, "++++++++++++++ check ++++++++++++++\n" );
        fprintf( stderr, "\tunfreed:\t%ld\n\tsize:\t\t%ld\n", s_mapManager.size(), alloc_size );
            
        for ( auto it = s_mapManager.begin(); it != s_mapManager.end(); ++it )
        {
            size_t          addr    = it->first;
            tagUnitNode*    pNode   = it->second;

            fprintf( stderr, "++++++++++++++ unfree addr: %x, size: %ld ++++++++++++++\n", \
                            addr, \
                            pNode->size );
            fprintf( stderr, "backtrace:\n" );
            for ( int i = 0; i < BT_BUF_SIZE; ++i )
                fprintf( stderr, "%s\n", pNode->backtrace[i] );     
            fprintf( stderr, "++++++++++++++ end ++++++++++++++\n" );
        }
    }
} // namespace MemoryManager
