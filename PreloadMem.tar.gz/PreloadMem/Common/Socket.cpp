#include "Socket.h"

namespace Socket
{
	#define LISTEN_BACKLOG      50

	CSocket::CSocket()
	{
		fd = -1;
    	memset( &addr, 0, sizeof( sockaddr_un ) );
		memset( path, 0, 128 );
	}

	CSocket::~CSocket()
	{
		;
	}

	bool CSocket::initSocket( bool isServer, const char* path )
	{
		fd = socket( AF_UNIX, SOCK_STREAM, 0 );
		assert( -1 != fd );

    	memset( &addr, 0, sizeof( sockaddr_un ) );
    	addr.sun_family = AF_UNIX;
    	strncpy( addr.sun_path, path, sizeof( addr.sun_path ) - 1 );
		assert( -1 != bind( fd, ( sockaddr* )&addr, sizeof( sockaddr_un ) ) );
		unlink( path );

		if ( isServer )
	    	assert( -1 != listen( fd, LISTEN_BACKLOG ) );

		return true;
	}

	void CSocket::connect( const char* path )
	{
		;	
	}

	void CSocket::close()
	{
		;
	}
	
	size_t CSocket::recv()
	{
		;
	}

	size_t CSocket::send()
	{
		;
	}
}
