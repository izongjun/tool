#include "Socket.h"

#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <assert.h>

namespace Socket
{
	#define LISTEN_BACKLOG      50

	CSocket::CSocket()
	{
		m_fd = -1;
    	memset( &m_addr, 0, sizeof( sockaddr_un ) );
		memset( m_path, 0, 128 );
	}

	CSocket::~CSocket()
	{
		close();
	}

	bool CSocket::initSocket( bool isServer, const char* path )
	{
		m_fd = socket( AF_UNIX, SOCK_STREAM, 0 );
		assert( -1 != m_fd );
		
    	memset( &m_addr, 0, sizeof( sockaddr_un ) );
    	m_addr.sun_family = AF_UNIX;
    	strncpy( m_addr.sun_path, path, sizeof( m_addr.sun_path ) - 1 );

		unlink( path );
		assert( -1 != ::bind( m_fd, ( sockaddr* )(&m_addr), sizeof( sockaddr_un ) ) );

		if ( isServer )
	    	assert( -1 != ::listen( m_fd, LISTEN_BACKLOG ) );

		strncpy( m_path, path, 128 );

		return true;
	}

	void CSocket::connect( const char* path )
	{
		sockaddr_un server_addr;

		server_addr.sun_family = AF_UNIX;
		strncpy( server_addr.sun_path, path, sizeof( server_addr.sun_path ) - 1 );
		
		assert( -1 != ::connect( m_fd, ( sockaddr* )&server_addr, sizeof( sockaddr_un ) ) );
	}

	void CSocket::close()
	{
		if ( -1 != m_fd ) ::close( m_fd );
	}
	
	size_t CSocket::recv()
	{
		return ::recv( m_fd, m_recvBuff, sizeof( m_recvBuff ), 0 );
	}

	size_t CSocket::send()
	{
		return ::send( m_fd, m_sendBuff, sizeof( m_sendBuff ), 0 );
	}
}
