#ifndef __SOCKETH__
#define __SOCKETH__

#include <stddef.h>
#include <sys/un.h>

namespace Socket 
{
	class CSocket 
	{
	public:
		struct tagRecord
		{
			int			 	sync;
			size_t 			size;
			void*			data;
			char			backtrace[1000];
		};

		#define DEF_SOCK_SYNC			0xFEEF9FF9CDDC9889
		#define DEF_SIZE_OF_RECORD		sizeof( tagRecord )

	public:
		bool						initSocket( bool isServer, const char* path );
		
		inline bool					available()			{ return (-1 != m_fd); }
		inline int					fd()				{ return m_fd; }
		inline void					fd( int sfd )		{ m_fd = sfd; }
		inline const sockaddr_un&	addr()				{ return m_addr; }
		inline const char*			path()				{ return m_path; }
		inline char*				buffer()			{ return m_recvBuff; }

		void						connect( const char* path );
		void						close();	
		
		size_t						recv();
		size_t						send();

		CSocket();
		virtual ~CSocket();

	private:
		int 			m_fd;
		sockaddr_un		m_addr;
		char			m_path[128];

		union {
			char			m_recvBuff[1024];
			char			m_sendBuff[1024];
		};
	};
} //namespace socket
#endif
