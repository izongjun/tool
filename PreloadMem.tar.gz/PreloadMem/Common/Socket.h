#ifndef __SOCKETH__
#define __SOCKETH__

namespace Socket 
{
	class CSocket 
	{
	public:
		struct tagRecord
		{
			int			 	sync;
			size_t 			size;
			void*			data;
			char			backtrace[1000];
		};

		#define DEF_SOCK_SYNC			0xFEEF9FF9CDDC9889
		#define DEF_SIZE_OF_RECORD		sizeof( tagRecord )

	public:
		bool						initSocket( bool isServer, const char* path );
		
		inline bool					available()			{ return (-1 != fd); }
		inline int					fd()				{ return fd; }
		inline int					fd( int sfd )		{ fd = sfd; }
		inline const sockaddr_un&	addr()				{ return addr; }
		inline const char*			path()				{ return path; }
		inline size_t				size()				{ return size; }
		inline char*				buffer()			{ return recvBuff; }

		void						connect( const char* path );
		void						close();	
		
		size_t						recv();
		size_t						send();

		CSocket();
		virtual ~CSocket();

	private:
		int 			fd;
		sockaddr_un		addr;
		char			path[128];

		union {
			char			recvBuff[1024];
			char			sendBuff[1024];
		}
	};
} //namespace socket
#endif
