#ifndef __SOCKETH__
#define __SOCKETH__

#include <stddef.h>
#include <sys/un.h>

namespace Socket 
{
	#define BT_BUF_SIZE 	20
	class CSocket 
	{
	public:
		struct tagRecord
		{
			size_t			sync;
			size_t 			size;
			void*			data;
			char			backtrace[BT_BUF_SIZE][128];
		};

	public:
		bool						initSocket( bool isServer, const char* path );
		
		inline bool					available()			{ return (-1 != m_fd); }
		inline int					fd()				{ return m_fd; }
		inline void					fd( int sfd )		{ m_fd = sfd; }
		inline const sockaddr_un&	addr()				{ return m_addr; }
		inline const char*			path()				{ return m_path; }
		inline char*				buffer()			{ return (char*)&m_record; }

		bool						connect( const char* path );
		void						close();	
		
		size_t						recv();
		size_t						send();

		CSocket();
		virtual ~CSocket();

	private:
		int 					m_fd;
		sockaddr_un				m_addr;
		char					m_path[128];

		tagRecord				m_record;
	};

	#define DEF_SOCK_SYNC			0xFEEF9FF9CDDC9889
	#define DEF_SIZE_OF_RECORD		sizeof( ::Socket::CSocket::tagRecord ) 
} //namespace socket
#endif
